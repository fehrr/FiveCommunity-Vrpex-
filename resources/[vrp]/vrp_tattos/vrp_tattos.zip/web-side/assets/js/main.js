const App = {
  shop: {},
  selectedItems: {},
  containerItems: $(".items"),
  hasBought: false,
  openNui: (newShop, atualTattoo) => {
    App.shop = newShop;
    App.atualTattoo = atualTattoo;
    $("body").css("display", "flex");
    $(".categories button.selected").click();

    document.querySelector('.buttons input').value = 0
    document.querySelector('.buttons div span > p').innerHTML = `0º`
  },
  
  rotate: (element) =>  {
    document.querySelector('.buttons div span > p').innerHTML = `${element.value}º`
    SendRequest("rotate", {
      heading: Number(element.value),
    });
  },

  selectCategory: (element, category) => {
    $("button").removeClass("selected");
    $(element).addClass("selected");

    App.containerItems.empty();

    let htmlToAdd = "";
    App.shop[category].tattoo.forEach((tattoo, key) => {
      const activeClass = Object.keys(App.atualTattoo).includes(tattoo.name) ? "selected" : "";
      const imageUrl = `http://177.54.148.31:4020/tattos/${category}/${tattoo.name}.jpg`;
      htmlToAdd += `
        <div 
          class="item ${activeClass}" 
          data-key="${key}" 
          data-category="${category}"
          onclick="App.selectItem(this)"
        >
          <svg class="check" width="42" height="34" viewBox="0 0 42 34" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g>
            <path d="M22.4884 19.1495C21.5661 19.6765 20.4339 19.6765 19.5116 19.1495L15.5116 16.8637C14.5769 16.3296 14 15.3356 14 14.259L14 9.74078C14 8.66419 14.5769 7.67013 15.5116 7.13601L19.5116 4.85044C20.4339 4.32346 21.5661 4.32346 22.4884 4.85044L26.4883 7.13601C27.4231 7.67013 28 8.66418 28 9.74078L28 14.259C28 15.3356 27.4231 16.3296 26.4884 16.8637L22.4884 19.1495Z" fill="#EE313B"/>
            <path d="M22.2404 18.7153C21.4718 19.1545 20.5282 19.1545 19.7596 18.7153L15.7596 16.4296C14.9807 15.9845 14.5 15.1562 14.5 14.259L14.5 9.74078C14.5 8.84362 14.9807 8.01524 15.7597 7.57014L19.7597 5.28456C20.5283 4.84542 21.4717 4.84542 22.2403 5.28456L26.2403 7.57014C27.0193 8.01524 27.5 8.84362 27.5 9.74078L27.5 14.259C27.5 15.1562 27.0193 15.9845 26.2404 16.4296L22.2404 18.7153Z" stroke="#D3132F"/>
            </g>
            <path d="M24.9711 10.0336L19.9711 15.0336C19.9421 15.0626 19.9077 15.0857 19.8697 15.1014C19.8318 15.1171 19.7911 15.1252 19.7501 15.1252C19.709 15.1252 19.6683 15.1171 19.6304 15.1014C19.5924 15.0857 19.558 15.0626 19.529 15.0336L17.3415 12.8461C17.2828 12.7874 17.2499 12.7079 17.2499 12.625C17.2499 12.5421 17.2828 12.4625 17.3415 12.4039C17.4001 12.3453 17.4796 12.3123 17.5626 12.3123C17.6455 12.3123 17.725 12.3453 17.7836 12.4039L19.7501 14.3707L24.529 9.5914C24.5876 9.53276 24.6671 9.49982 24.7501 9.49982C24.833 9.49982 24.9125 9.53276 24.9711 9.5914C25.0298 9.65003 25.0627 9.72956 25.0627 9.81249C25.0627 9.89542 25.0298 9.97495 24.9711 10.0336Z" fill="white"/>
          </svg>

          <div class="image" style="background-image: url('${imageUrl}')"></div>
          <div class="number">${key}</div>
        </div>
      `;
    });
    App.containerItems.append(htmlToAdd);
  },
  selectItem: async (element) => {
    const key = element.dataset.key;
    const category = element.dataset.category;

    element.classList.toggle("selected");

    if (element.classList.contains("selected")) {
      App.selectedItems[`${category}-${key}`] = true;
    } else {
      delete App.selectedItems[`${category}-${key}`];
    }
    SendRequest("changeTattoo", { type: category, id: key });
  },
  clearItems: () => {
    $(".item").removeClass("selected");
    App.selectedItems = {};
    SendRequest("clearTattoo");
  },
  buyTattoos: () => {
    App.close();
    SendRequest("finishTattoos", {
      price: 200,
    });
  },
  close: () => {
    $("body").css("display", "none");
    App.selectedItems = {};
    SendRequest("close");
  },
};

if (!window.invokeNative) {
  document.body.style.display = 'block'
  // document.body.style.background = '#1c1c1c'
}

$(document).ready(() => {
  
  

  window.addEventListener("message", ({ data }) => {
    const { openNui, shop, tattoo } = data;
    if (openNui) App.openNui(shop, tattoo);
  });

  document.querySelectorAll(".set-camera").forEach((e) => {
    e.addEventListener("click", () => {
      document.querySelectorAll(".set-camera").forEach((div) => div.parentElement.classList.remove('selected'));
      e.parentElement.classList.add('selected');
      SendRequest("setupCam", {
        value: Number(e.dataset.value),
      });
    });
  });
});

async function SendRequest(route, body = {}) {
  try {
    if (!window.isOnline) {
      console.log("NOT CONNECTED");
      return;
    }

    const response = await fetch(
      `http://${window.GetParentResourceName()}/${route}`,
      {
        method: "POST",
        headers: {
          "Content-type": "application/json; charset=UTF-8",
        },
        body: JSON.stringify(body),
      }
    );

    return await response.json();
  } catch (error) {
    
  }
}

document.addEventListener("keydown", ({ key }) => {
  if (key === "Escape") {
    $("body").css("display", "none");
    SendRequest("close")
  }
  if (key === "a") SendRequest("rotateLeft");
  if (key === "d") SendRequest("rotateRight");
});