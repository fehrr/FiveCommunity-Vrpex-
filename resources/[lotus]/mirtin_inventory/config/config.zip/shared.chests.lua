Chests = {
	-- Legal
	['Policia'] = {
		coords = vec3(-1658.29,174.14,61.77),
		permission = 'perm.disparo',
		max_weight = 3000,
	},
	['Prf'] = {
		coords = vec3(2610.11,5346.52,47.57),
		permission = 'perm.liderprf',
		max_weight = 3000,
	},
	['Choque'] = {
		coords = vec3(475.21,-1006.44,34.22),
		permission = 'perm.liderchoque',
		max_weight = 3000,
	},
	['Pf'] = {
		coords = vec3(-799.52,-1231.18,6.86),
		permission = 'perm.baupoliciafederallider',
		max_weight = 3000,
	},
	['Rota'] = {
		coords = vec3(-1088.82,-819.21,11.04),
		permission = 'perm.liderrota',
		max_weight = 3000,
	},
	['Tatica'] = {
		coords = vec3(-1698.97,-758.41,10.75),
		permission = 'perm.baulidertatica',
		max_weight = 3000,
	},
	['Core'] = {
		coords = vec3(-2060.95,-451.12,12.27),
		permission = 'perm.baulidercore',
		max_weight = 3000,
	},
	['Civil'] = {
		coords = vec3(-421.1,1095.02,327.68),
		permission = 'perm.baupoliciacivillider',
		max_weight = 3000,
	},
	['Baep'] = {
		coords = vec3(363.78,-1583.92,33.35),
		permission = 'perm.liderbaep',
		max_weight = 3000,
	},
	['Exercito'] = {
		coords = vec3(-2190.1,3188.5,32.82),
		permission = 'perm.liderexercito',
		max_weight = 3000,
	},
	['Judiciario'] = {
		coords = vec3(-523.23,-193.01,38.22),
		permission = 'perm.judiciario',
		max_weight = 3000,
	},
	['Mecanica'] = {
		coords = vec3(456.77,-1321.3,29.34),
		permission = 'perm.lidermecanica',
		max_weight = 3000,
	},
	['Race'] = {
		coords = vec3(835.89,-934.31,32.39),
		permission = 'perm.liderrace',
		max_weight = 3000,
	},
	['Driftking'] = {
		coords = vec3(-339.57,-157.31,44.58),
		permission = 'perm.liderdriftking',
		max_weight = 3000,
	},

	-- Facções
	['Magnatas'] = {
		coords = vec3(-2947.31,48.24,11.61),
		permission = 'perm.baumagnatas',
		max_weight = 3000,
	},
	['Anonymous'] = {
		coords = vec3(-1528.16,842.95,181.59),
		permission = 'perm.bauanonymous',
		max_weight = 3000,
	},
	['Pcc'] = {
		coords = vec3(-1659.5,-260.72,58.99),
		permission = 'perm.baupcc',
		max_weight = 3000,
	},
	['Gerente-Pcc'] = {
		coords = vec3(-1659.45,-260.76,58.99),
		permission = 'perm.gerentepcc',
		max_weight = 23000,
	},
	['Lider-Pcc'] = {
		coords = vec3(-1658.95,-267.25,58.99),
		permission = 'perm.liderpcc',
		max_weight = 33000,
	},
	['Inglaterra'] = {
		coords = vec3(-1526.43,109.14,55.64),
		permission = 'perm.bauinglaterra',
		max_weight = 3000,
	},
	['Gerente-Inglaterra'] = {
		coords = vec3(-1532.95,151.52,56.11),
		permission = 'perm.gerenteinglaterra',
		max_weight = 23000,
	},
	['Lider-Inglaterra'] = {
		coords = vec3(-1532.95,151.52,56.11),
		permission = 'perm.lideringlaterra',
		max_weight = 33000,
	},
	['Yakuza'] = {
		coords = vec3(-902.65,-1445.82,7.53),
		permission = 'perm.bauyakuza',
		max_weight = 3000,
	},
	['Korea'] = {
		coords = vec3(433.15,8.59,91.93),
		permission = 'perm.baukorea',
		max_weight = 3000,
	},
	['Mafia'] = {
		coords = vec3(-811.39,181.19,76.73),
		permission = 'perm.baumafia',
		max_weight = 3000,
	},
	['Grota'] = {
		coords = vec3(1243.15,-109.6,75.3),
		permission = 'perm.baugrota',
		max_weight = 3000,
	},
	['Japao'] = {
		coords = vec3(-177.6,305.87,97.46),
		permission = 'perm.baujapao',
		max_weight = 3000,
	},
	['Milicia'] = {
		coords = vec3(-620.0,-1617.86,33.01),
		permission = 'perm.baumilicia',
		max_weight = 3000,
	},
	['Cartel'] = {
		coords = vec3(428.4,-1505.76,29.32),
		permission = 'perm.baucartel',
		max_weight = 3000,
	},
	['Espanha'] = {
		coords = vec3(-2259.94,-262.95,63.51),
		permission = 'perm.bauespanha',
		max_weight = 3000,
	},
	['Umbrella'] = {
		coords = vec3(-1048.07,297.13,62.21),
		permission = 'perm.bauumbrella',
		max_weight = 3000,
	},
	['Suica'] = {
		coords = vec3(-1777.6,455.81,128.31),
		permission = 'perm.bausuica',
		max_weight = 3000,
	},
	['Bronks'] = {
		coords = vec3(1345.93,-680.76,88.55),
		permission = 'perm.baubronks',
		max_weight = 3000,
	},
	['Motoclube'] = {
		coords = vec3(978.3,-82.14,73.95),
		permission = 'perm.baumotoclube',
		max_weight = 3000,
	},
	['Bennys'] = {
		coords = vec3(-242.55,-1329.32,30.89),
		permission = 'perm.baubennys',
		max_weight = 3000,
	},
	['Cohab'] = {
		coords = vec3(-1561.14,-376.33,38.91),
		permission = 'perm.baucohab',
		max_weight = 3000,
	},
	['Baixada'] = {
		coords = vec3(-1182.0,-1736.53,11.9),
		permission = 'perm.baubaixada',
		max_weight = 3000,
	},
	['Cassino'] = {
		coords = vec3(961.68,21.92,76.99),
		permission = 'perm.baucassino',
		max_weight = 3000,
	},
	['Bahamas'] = {
		coords = vec3(-1378.66,-597.89,30.31),
		permission = 'perm.baubahamas',
		max_weight = 3000,
	},
	['Lifeinvader'] = {
		coords = vec3(-1062.84,-250.11,44.01),
		permission = 'perm.baulifeinvader',
		max_weight = 3000,
	},
	['China'] = {
		coords = vec3(-818.17,-717.86,23.78),
		permission = 'perm.bauchina',
		max_weight = 3000,
	},
	['Lux'] = {
		coords = vec3(-281.56,223.48,78.82),
		permission = 'perm.baulux',
		max_weight = 3000,
	},
	['Gerente-Lux'] = {
		coords = vec3(-318.39,211.28,81.77),
		permission = 'perm.gerentelux',
		max_weight = 3000,
	},
	['Lider-Lux'] = {
		coords = vec3(-307.09,209.19,145.31),
		permission = 'perm.liderlux',
		max_weight = 3000,
	},
	['Galaxy'] = {
		coords = vec3(-437.49,-36.09,40.88),
		permission = 'perm.baugalaxy',
		max_weight = 3000,
	},
	['Lacoste'] = {
		coords = vec3(730.53,-1067.07,22.16),
		permission = 'perm.baulacoste',
		max_weight = 3000,
	},
	['Tequila'] = {
		coords = vec3(-573.89,293.36,79.18),
		permission = 'perm.bautequila',
		max_weight = 3000,
	},
	['Cosanostra'] = {
		coords = vec3(-1719.92,620.88,181.52),
		permission = 'perm.baucosanostra',
		max_weight = 3000,
	},
	['Elements'] = {
		coords = vec3(-152.7,-1590.48,35.35),
		permission = 'perm.bauelements',
		max_weight = 3000,
	},
	['Sintonia'] = {
		coords = vec3(898.41,380.14,124.91),
		permission = 'perm.bausintonia',
		max_weight = 3000,
	},
	['Gerente-Sintonia'] = {
		coords = vec3(906.36,370.59,112.57),
		permission = 'perm.gerentesintonia',
		max_weight = 13000,
	},
	['Lider-Sintonia'] = {
		coords = vec3(907.6,380.83,124.91),
		permission = 'perm.lidersintonia',
		max_weight = 23000,
	},
	['Grecia'] = {
		coords = vec3(-345.82,-1518.3,33.19),
		permission = 'perm.baugrecia',
		max_weight = 3000,
	},
	['Colombia'] = {
		coords = vec3(-1138.15,365.04,71.31),
		permission = 'perm.baucolombia',
		max_weight = 3000,
	},
	['Brazuca'] = {
		coords = vec3(1230.88,-1042.89,50.13),
		permission = 'perm.baubrazuca',
		max_weight = 3000,
	},
	['Russia'] = {
		coords = vec3(786.35,-257.44,77.71),
		permission = 'perm.baurussia',
		max_weight = 3000,
	},
	['Gerente-Russia'] = {
		coords = vec3(678.9,-321.03,57.95),
		permission = 'perm.gerenterussia',
		max_weight = 23000,
	},
	['Lider-Russia'] = {
		coords = vec3(802.2,-292.02,69.89),
		permission = 'perm.liderrussia',
		max_weight = 33000,
	},
	['Roxos'] = {
		coords = vec3(113.83,-1965.75,21.33),
		permission = 'perm.bauroxos',
		max_weight = 3000,
	},

	-- Mansao
	['IlhaRonas'] = {
		coords = vec3(-3315.33,574.2,11.34),
		permission = 'perm.ilharonas',
		max_weight = 3000,
	},
}