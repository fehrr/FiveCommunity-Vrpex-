CraftConfig = {
    Tables = {
-------------- [ DOMINAS ] --------------
        ['Dominacao [ARMAS]'] = {
            Config = {
                hasDominas = 'Armas',
                permission = 'perm.gerentearma',
                location = vec3(583.53,-3110.94,6.07)
            },

            Itens = {
                {
                    item = "WEAPON_APPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)

                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 60 },  
                        { item = "metal" , amount = 60 }
                    }
                },

                {
                    item = "WEAPON_MICROSMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)

                    requires = {
                        { item = "pecadearma" , amount = 300 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 75 },  
                        { item = "metal" , amount = 75 }
                    }
                },

                {
                    item = "WEAPON_PUMPSHOTGUN_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)

                    requires = {
                        { item = "pecadearma" , amount = 1000 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 200 },  
                        { item = "metal" , amount = 200 }
                    }
                },
            }
        },

        ['Dominacao [MUNICAO]'] = {
            Config = {
                hasDominas = 'Municao',
                permission = "perm.craftmuni",
                location = vec3(121.18,-3103.78,6.02)
            },

            Itens = {
                {
                    item = "AMMO_APPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)

                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                    }
                },

                {
                    item = "AMMO_MICROSMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)

                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                    }
                },

                {
                    item = "AMMO_PUMPSHOTGUN_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)

                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                    }
                },
            }
        },

        ['Dominacao [LAVAGEM]'] = {
            Config = {
                hasDominas = 'Lavagem',
                permission = 'perm.craftlavagem',
                location = vec3(-234.42,-1999.2,24.69)
            },

            Itens = {
                {
                    item = "money", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 180000, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "dirty_money" , amount = 200000 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "l-alvejante" , amount = 20 }  
                    }
                },

            }
        },

        ['Dominacao [DESMANCHE]'] = {
            Config = {
                hasDominas = 'Desmanche',
                permission = 'perm.craftdesmanche',
                location = vec3(2330.89,3056.1,48.16)
            },

            Itens = {
                {
                    item = "lockpick", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 50 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 50 }  
                    }
                },

            }
        },

-------------- [ MESAS ] --------------
        -- ARMAS
        ['Inglaterra'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerenteinglaterra',
                location = vec3(-1530.15,148.77,60.79)
            },

            Itens = {
                {
                    item = "WEAPON_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "pecadearma" , amount = 50, }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 30 },  
                        { item = "metal" , amount = 30 }
                    }
                },
                
                {
                    item = "WEAPON_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 90 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 45 },  
                        { item = "metal" , amount = 45 }
                    }
                },
                
                {
                    item = "WEAPON_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 200 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 60 },  
                        { item = "metal" , amount = 60 }
                    }
                },  
                
                {
                    item = "WEAPON_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 65 },  
                        { item = "metal" , amount = 65 }
                    }
                },  
        
                {
                    item = "WEAPON_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 75 },  
                        { item = "metal" , amount = 75 }
                    }
                },  
                
                {
                    item = "WEAPON_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 300 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 90 },  
                        { item = "metal" , amount = 90 }
                    }
                },  
                
                {
                    item = "WEAPON_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]    
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 380 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 120 },  
                        { item = "metal" , amount = 120 }
                    }
                }
            }
        },
        ['PCC'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentepcc',
                location = vec3(-1744.7,-253.54,52.96)
            },

            Itens = {
                {
                    item = "WEAPON_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "pecadearma" , amount = 50, }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 30 },  
                        { item = "metal" , amount = 30 }
                    }
                },
                
                {
                    item = "WEAPON_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 90 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 45 },  
                        { item = "metal" , amount = 45 }
                    }
                },
                
                {
                    item = "WEAPON_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 200 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 60 },  
                        { item = "metal" , amount = 60 }
                    }
                },  
                
                {
                    item = "WEAPON_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 65 },  
                        { item = "metal" , amount = 65 }
                    }
                },  
        
                {
                    item = "WEAPON_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 75 },  
                        { item = "metal" , amount = 75 }
                    }
                },  
                
                {
                    item = "WEAPON_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 300 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 90 },  
                        { item = "metal" , amount = 90 }
                    }
                },  
                
                {
                    item = "WEAPON_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]    
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 380 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 120 },  
                        { item = "metal" , amount = 120 }
                    }
                }
            }
        },
        ['Mafia'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentemafia',
                location = vec3(-1502.91,835.31,177.04)
            },

            Itens = {
                {
                    item = "WEAPON_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "pecadearma" , amount = 50, }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 30 },  
                        { item = "metal" , amount = 30 }
                    }
                },
                
                {
                    item = "WEAPON_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 90 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 45 },  
                        { item = "metal" , amount = 45 }
                    }
                },
                
                {
                    item = "WEAPON_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 200 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 60 },  
                        { item = "metal" , amount = 60 }
                    }
                },  
                
                {
                    item = "WEAPON_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 65 },  
                        { item = "metal" , amount = 65 }
                    }
                },  
        
                {
                    item = "WEAPON_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 75 },  
                        { item = "metal" , amount = 75 }
                    }
                },  
                
                {
                    item = "WEAPON_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 300 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 90 },  
                        { item = "metal" , amount = 90 }
                    }
                },  
                
                {
                    item = "WEAPON_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]    
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 380 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 120 },  
                        { item = "metal" , amount = 120 }
                    }
                }
            }
        },
        ['CV'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentecv',
                location = vec3(3029.49,3008.73,91.58)
            },

            Itens = {
                {
                    item = "WEAPON_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "pecadearma" , amount = 50, }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 30 },  
                        { item = "metal" , amount = 30 }
                    }
                },
                
                {
                    item = "WEAPON_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 90 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 45 },  
                        { item = "metal" , amount = 45 }
                    }
                },
                
                {
                    item = "WEAPON_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 200 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 60 },  
                        { item = "metal" , amount = 60 }
                    }
                },  
                
                {
                    item = "WEAPON_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 65 },  
                        { item = "metal" , amount = 65 }
                    }
                },  
        
                {
                    item = "WEAPON_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 75 },  
                        { item = "metal" , amount = 75 }
                    }
                },  
                
                {
                    item = "WEAPON_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 300 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 90 },  
                        { item = "metal" , amount = 90 }
                    }
                },  
                
                {
                    item = "WEAPON_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]    
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 380 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 120 },  
                        { item = "metal" , amount = 120 }
                    }
                }
            }
        },
        ['Milicia'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentemilicia',
                location = vec3(-3096.89,1722.04,36.13)
            },

            Itens = {
                {
                    item = "WEAPON_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "pecadearma" , amount = 50, }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 30 },  
                        { item = "metal" , amount = 30 }
                    }
                },
                
                {
                    item = "WEAPON_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 90 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 45 },  
                        { item = "metal" , amount = 45 }
                    }
                },
                
                {
                    item = "WEAPON_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 200 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 60 },  
                        { item = "metal" , amount = 60 }
                    }
                },  
                
                {
                    item = "WEAPON_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 65 },  
                        { item = "metal" , amount = 65 }
                    }
                },  
        
                {
                    item = "WEAPON_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 75 },  
                        { item = "metal" , amount = 75 }
                    }
                },  
                
                {
                    item = "WEAPON_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 300 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 90 },  
                        { item = "metal" , amount = 90 }
                    }
                },  
                
                {
                    item = "WEAPON_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]    
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 380 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 120 },  
                        { item = "metal" , amount = 120 }
                    }
                }
            }
        },
        ['Egito'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerenteegito",
                location = vec3(391.32,-9.61,86.68)
            },

            Itens = {
                {
                    item = "WEAPON_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "pecadearma" , amount = 50, }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 30 },  
                        { item = "metal" , amount = 30 }
                    }
                },
                
                {
                    item = "WEAPON_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 90 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 45 },  
                        { item = "metal" , amount = 45 }
                    }
                },
                
                {
                    item = "WEAPON_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 200 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 60 },  
                        { item = "metal" , amount = 60 }
                    }
                },  
                
                {
                    item = "WEAPON_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 65 },  
                        { item = "metal" , amount = 65 }
                    }
                },  
        
                {
                    item = "WEAPON_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 75 },  
                        { item = "metal" , amount = 75 }
                    }
                },  
                
                {
                    item = "WEAPON_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 300 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 90 },  
                        { item = "metal" , amount = 90 }
                    }
                },  
                
                {
                    item = "WEAPON_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]    
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 380 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 120 },  
                        { item = "metal" , amount = 120 }
                    }
                }
            }
        },
        ['Magnatas'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentemagnatas",
                location = vec3(-2997.19,69.42,16.23)
            },

            Itens = {
                {
                    item = "WEAPON_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "pecadearma" , amount = 50, }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 30 },  
                        { item = "metal" , amount = 30 }
                    }
                },
                
                {
                    item = "WEAPON_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 90 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 45 },  
                        { item = "metal" , amount = 45 }
                    }
                },
                
                {
                    item = "WEAPON_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 200 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 60 },  
                        { item = "metal" , amount = 60 }
                    }
                },  
                
                {
                    item = "WEAPON_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 65 },  
                        { item = "metal" , amount = 65 }
                    }
                },  
        
                {
                    item = "WEAPON_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 75 },  
                        { item = "metal" , amount = 75 }
                    }
                },  
                
                {
                    item = "WEAPON_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 300 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 90 },  
                        { item = "metal" , amount = 90 }
                    }
                },  
                
                {
                    item = "WEAPON_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]    
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 380 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 120 },  
                        { item = "metal" , amount = 120 }
                    }
                }
            }
        },
        -- ['Playboy'] = {
        --     Config = {
        --         hasDominas = nil,
        --         permission = "perm.gerenteplayboy",
        --         location = vec3(-1534.07,148.41,60.79)
        --     },

        --     Itens = {
        --         {
        --             item = "WEAPON_SNSPISTOL_MK2", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 1, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
        --             requires = {
        --                 { item = "pecadearma" , amount = 50, }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "gatilho" , amount = 1 },  
        --                 { item = "molas" , amount = 30 },  
        --                 { item = "metal" , amount = 30 }
        --             }
        --         },
                
        --         {
        --             item = "WEAPON_PISTOL_MK2", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 1, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
        --             requires = {
        --                 { item = "pecadearma" , amount = 90 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "gatilho" , amount = 1 },  
        --                 { item = "molas" , amount = 45 },  
        --                 { item = "metal" , amount = 45 }
        --             }
        --         },
                
        --         {
        --             item = "WEAPON_MACHINEPISTOL", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 1, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
        --             requires = {
        --                 { item = "pecadearma" , amount = 200 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "gatilho" , amount = 1 },  
        --                 { item = "molas" , amount = 60 },  
        --                 { item = "metal" , amount = 60 }
        --             }
        --         },  
                
        --         {
        --             item = "WEAPON_SMG", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 1, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
        --             requires = {
        --                 { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "gatilho" , amount = 1 },  
        --                 { item = "molas" , amount = 65 },  
        --                 { item = "metal" , amount = 65 }
        --             }
        --         },  
        
        --         {
        --             item = "WEAPON_ASSAULTRIFLE", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 1, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
        --             requires = {
        --                 { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "gatilho" , amount = 1 },  
        --                 { item = "molas" , amount = 75 },  
        --                 { item = "metal" , amount = 75 }
        --             }
        --         },  
                
        --         {
        --             item = "WEAPON_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 1, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
        --             requires = {
        --                 { item = "pecadearma" , amount = 300 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "gatilho" , amount = 1 },  
        --                 { item = "molas" , amount = 90 },  
        --                 { item = "metal" , amount = 90 }
        --             }
        --         },  
                
        --         {
        --             item = "WEAPON_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]    
        --             customAmount = 1, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
        --             requires = {
        --                 { item = "pecadearma" , amount = 380 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "gatilho" , amount = 1 },  
        --                 { item = "molas" , amount = 120 },  
        --                 { item = "metal" , amount = 120 }
        --             }
        --         }
        --     }
        -- },
        ['Grota'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentegrota',
                location = vec3(1270.63,-126.3,87.64)
            },

            Itens = {
                {
                    item = "WEAPON_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "pecadearma" , amount = 50, }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 30 },  
                        { item = "metal" , amount = 30 }
                    }
                },
                
                {
                    item = "WEAPON_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 90 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 45 },  
                        { item = "metal" , amount = 45 }
                    }
                },
                
                {
                    item = "WEAPON_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 200 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 60 },  
                        { item = "metal" , amount = 60 }
                    }
                },  
                
                {
                    item = "WEAPON_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 65 },  
                        { item = "metal" , amount = 65 }
                    }
                },  
        
                {
                    item = "WEAPON_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 250 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 75 },  
                        { item = "metal" , amount = 75 }
                    }
                },  
                
                {
                    item = "WEAPON_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 300 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 90 },  
                        { item = "metal" , amount = 90 }
                    }
                },  
                
                {
                    item = "WEAPON_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]    
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
    
                    requires = {
                        { item = "pecadearma" , amount = 380 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "gatilho" , amount = 1 },  
                        { item = "molas" , amount = 120 },  
                        { item = "metal" , amount = 120 }
                    }
                }
            }
        },

        -- MUNICAO
        ['Cartel'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentecartel',
                location = vec3(1398.44,1152.43,108.14)
            },

            Itens = {
                {
                    item = "AMMO_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 75 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 5000 },  
                    }
                },
                
                {
                    item = "AMMO_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                
                {
                    item = "AMMO_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                 
                {
                    item = "AMMO_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 15000 },  
                    }
                },
                
                {
                    item = "AMMO_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 30000 },  
                    }
                },
            }
        },
        ['Tequila'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentetequila',
                location = vec3(169.5,1705.18,227.39)
            },

            Itens = {
                {
                    item = "AMMO_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 75 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 5000 },  
                    }
                },
                
                {
                    item = "AMMO_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                
                {
                    item = "AMMO_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                 
                {
                    item = "AMMO_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 15000 },  
                    }
                },
                
                {
                    item = "AMMO_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 30000 },  
                    }
                },
            }
        },
        ['Escocia'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerenteescocia',
                location = vec3(1391.94,-2533.54,55.05)
            },

            Itens = {
                {
                    item = "AMMO_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 75 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 5000 },  
                    }
                },
                
                {
                    item = "AMMO_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                
                {
                    item = "AMMO_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                 
                {
                    item = "AMMO_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 15000 },  
                    }
                },
                
                {
                    item = "AMMO_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 30000 },  
                    }
                },
            }
        },
        ['Espanha'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerenteespanha',
                location = vec3(-1482.71,-34.86,51.31)
            },

            Itens = {
                {
                    item = "AMMO_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 75 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 5000 },  
                    }
                },
                
                {
                    item = "AMMO_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                
                {
                    item = "AMMO_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                 
                {
                    item = "AMMO_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 15000 },  
                    }
                },
                
                {
                    item = "AMMO_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 30000 },  
                    }
                },
            }
        },
        -- ['Cyclone'] = {
        --     Config = {
        --         hasDominas = nil,
        --         permission = 'perm.gerentecyclone',
        --         location = vec3(-1143.58,369.06,71.31)
        --     },

        --     Itens = {
        --         {
        --             item = "AMMO_SNSPISTOL_MK2", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 100, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
        --             requires = {
        --                 { item = "polvora" , amount = 75 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "capsulas" , amount = 100 }  
        --             }
        --         },

        --         {
        --             item = "AMMO_PISTOL_MK2", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 100, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
        --             requires = {
        --                 { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "capsulas" , amount = 100 }  
        --             }
        --         },

        --         {
        --             item = "AMMO_ASSAULTRIFLE", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 100, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
        --             requires = {
        --                 { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "capsulas" , amount = 100 },  
        --                 { item = "money" , amount = 5000 },  
        --             }
        --         },
                
        --         {
        --             item = "AMMO_SMG", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 100, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
        --             requires = {
        --                 { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "capsulas" , amount = 100 },  
        --                 { item = "money" , amount = 10000 },  
        --             }
        --         },
                
        --         {
        --             item = "AMMO_MACHINEPISTOL", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 100, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
        --             requires = {
        --                 { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "capsulas" , amount = 100 },  
        --                 { item = "money" , amount = 10000 },  
        --             }
        --         },
                 
        --         {
        --             item = "AMMO_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 100, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
        --             requires = {
        --                 { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "capsulas" , amount = 100 },  
        --                 { item = "money" , amount = 15000 },  
        --             }
        --         },
                
        --         {
        --             item = "AMMO_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
        --             time = 7, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 100, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
        --             requires = {
        --                 { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --                 { item = "capsulas" , amount = 100 },  
        --                 { item = "money" , amount = 30000 },  
        --             }
        --         },
        --     }
        -- },
        ['Yakuza'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.lideryakuza',
                location = vec3(-877.14,-1449.49,7.57)
            },

            Itens = {
                {
                    item = "AMMO_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 75 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 5000 },  
                    }
                },
                
                {
                    item = "AMMO_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                
                {
                    item = "AMMO_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                 
                {
                    item = "AMMO_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 15000 },  
                    }
                },
                
                {
                    item = "AMMO_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 30000 },  
                    }
                },
            }
        },
        ['ADA'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerenteada',
                location = vec3(782.06,-257.8,77.71)
            },

            Itens = {
                {
                    item = "AMMO_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 75 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 5000 },  
                    }
                },
                
                {
                    item = "AMMO_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                
                {
                    item = "AMMO_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                 
                {
                    item = "AMMO_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 15000 },  
                    }
                },
                
                {
                    item = "AMMO_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 30000 },  
                    }
                },
            }
        },

        ['TCP'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentelidertcp',
                location = vec3(1406.34,-771.58,74.27)
            },

            Itens = {
                {
                    item = "AMMO_SNSPISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 75 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_PISTOL_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 }  
                    }
                },

                {
                    item = "AMMO_ASSAULTRIFLE", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 5000 },  
                    }
                },
                
                {
                    item = "AMMO_SMG", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                
                {
                    item = "AMMO_MACHINEPISTOL", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 10000 },  
                    }
                },
                 
                {
                    item = "AMMO_ASSAULTRIFLE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 15000 },  
                    }
                },
                
                {
                    item = "AMMO_SPECIALCARBINE_MK2", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 100, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "polvora" , amount = 150 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "capsulas" , amount = 100 },  
                        { item = "money" , amount = 30000 },  
                    }
                },
            }
        },
        
        -- DESMANCHE
        ['CDD'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentelidercdd',
                location = vec3(-1188.43,-1729.96,11.9)
            },

            Itens = {
                {
                    item = "lockpick", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 50 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 50 }  
                    }
                },
                {
                    item = "ticket", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "papel" , amount = 20 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },
                {
                    item = "garrafanitro", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 50 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 50 },
                        { item = "money" , amount = 50000 }
                    }
                },
                {
                    item = "colete", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 60 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 60 }  
                    }
                },
            }
        },

        ['MotoClub'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentemotoclub',
                location = vec3(990.22,-98.04,74.85)
            },

            Itens = {
                {
                    item = "lockpick", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 50 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 50 }  
                    }
                },
                {
                    item = "ticket", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "papel" , amount = 20 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },
                {
                    item = "garrafanitro", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 50 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 50 },
                        { item = "money" , amount = 50000 }
                    }
                },
                {
                    item = "colete", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 60 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 60 }  
                    }
                },
            }
        },

        ['HellsAngels'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentehells',
                location = vec3(1037.12,-2527.14,28.31)
            },

            Itens = {
                {
                    item = "lockpick", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 50 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 50 }  
                    }
                },
                {
                    item = "ticket", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "papel" , amount = 20 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },
                {
                    item = "garrafanitro", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 50 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 50 },
                        { item = "money" , amount = 50000 }
                    }
                },
                {
                    item = "colete", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 60 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 60 }  
                    }
                },
            }
        },

        ['Lacoste'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentelacoste',
                location = vec3(730.3,-1072.0,22.16)
            },

            Itens = {
                {
                    item = "lockpick", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 50 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 50 }  
                    }
                },
                {
                    item = "ticket", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "papel" , amount = 20 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },
                {
                    item = "garrafanitro", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 50 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 50 },
                        { item = "money" , amount = 50000 }
                    }
                },
                {
                    item = "colete", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 60 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 60 }  
                    }
                },
            }
        },
        ['Pedreira'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentepedreira',
                location = vec3(1568.0,-2166.15,77.56)
            },

            Itens = {
                {
                    item = "lockpick", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 50 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 50 }  
                    }
                },
                {
                    item = "ticket", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "papel" , amount = 20 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },
                {
                    item = "garrafanitro", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 50 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 50 },
                        { item = "money" , amount = 50000 }
                    }
                },
                {
                    item = "colete", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 60 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 60 }  
                    }
                },
            }
        },
        ['Bennys'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentebennys',
                location = vec3(-203.88,-1341.36,30.89)
            },

            Itens = {
                {
                    item = "lockpick", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 50 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 50 }  
                    }
                },
                {
                    item = "ticket", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "papel" , amount = 20 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },
                {
                    item = "garrafanitro", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 50 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 50 },
                        { item = "money" , amount = 50000 }
                    }
                },
                {
                    item = "colete", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 60 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 60 }  
                    }
                },
            }
        },



-------------- [ LAVAGEM SEM DOMINACAO ]------------------------
        ['Vanilla'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentevanilla",
                location = vec3(121.2,-1280.88,29.47)
            },

            Itens = {
                {
                    item = "money", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 160000, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "dirty_money" , amount = 200000 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "l-alvejante" , amount = 20 }  
                    }
                },
                {
                    item = "capuz", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 20 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 20 }  
                    }
                },

                {
                    item = "corda", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 25 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 25 }  
                    }
                },

                {
                    item = "algemas", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 40 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 40 }  
                    }
                },
            }
        },
        ['Lux'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentelux",
                location = vec3(-281.41,223.43,78.82)
            },

            Itens = {
                {
                    item = "money", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 160000, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "dirty_money" , amount = 200000 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "l-alvejante" , amount = 20 }  
                    }
                },
                {
                    item = "capuz", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 20 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 20 }  
                    }
                },

                {
                    item = "corda", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 25 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 25 }  
                    }
                },

                {
                    item = "algemas", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 40 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 40 }  
                    }
                },
            }
        },
        ['Bahamas'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentebahamas",
                location = vec3(-1367.55,-625.49,30.31)
            },

            Itens = {
                {
                    item = "money", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 160000, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "dirty_money" , amount = 200000 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "l-alvejante" , amount = 20 }  
                    }
                },
                {
                    item = "capuz", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 20 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 20 }  
                    }
                },

                {
                    item = "corda", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 25 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 25 }  
                    }
                },

                {
                    item = "algemas", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 40 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 40 }  
                    }
                },
            }
        },
        ['Medusa'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentemedusa",
                location = vec3(755.65,-554.59,29.34)
            },

            Itens = {
                {
                    item = "money", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 160000, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "dirty_money" , amount = 200000 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "l-alvejante" , amount = 20 }  
                    }
                },
                {
                    item = "capuz", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 20 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 20 }  
                    }
                },

                {
                    item = "corda", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 25 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 25 }  
                    }
                },

                {
                    item = "algemas", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 40 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 40 }  
                    }
                },
            }
        },
        ['Galaxy'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentegalaxy",
                location = vec3(-217.31,-318.38,28.46)
            },

            Itens = {
                {
                    item = "money", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 160000, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "dirty_money" , amount = 200000 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "l-alvejante" , amount = 20 }  
                    }
                },
                {
                    item = "capuz", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 20 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 20 }  
                    }
                },

                {
                    item = "corda", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 25 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 25 }  
                    }
                },

                {
                    item = "algemas", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 40 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 40 }  
                    }
                },
            }
        },
        ['Cassino'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentecassino",
                location = vec3(950.77,32.83,71.83)
            },

            Itens = {
                {
                    item = "money", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 160000, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "dirty_money" , amount = 200000 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "l-alvejante" , amount = 20 }  
                    }
                },
                {
                    item = "capuz", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 20 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 20 }  
                    }
                },

                {
                    item = "corda", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "fibradecarbono" , amount = 25 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "poliester" , amount = 25 }  
                    }
                },

                {
                    item = "algemas", -- SPAWN DO ITEM
                    time = 7, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 1, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "ferro" , amount = 40 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                        { item = "aluminio" , amount = 40 }  
                    }
                },
            }
        },

-------------- [ OUTROS ] --------------            
        -- MACONHA
        ['Israel'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerenteisrael",
                location = vec3(-1627.18,333.47,74.73)
            },

            Itens = {
                {
                    item = "maconha", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "folhamaconha" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },
       

        ['Vidigal'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentevidigal",
                location = vec3(296.43,1858.87,209.65)
            },

            Itens = {
                {
                    item = "maconha", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "folhamaconha" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },

        -- COCAINA
        -- ['FavelaDaMare'] = {
        --     Config = {
        --         hasDominas = nil,
        --         permission = "perm.gerentefaveladamare",
        --         location = vec3(-1908.97,4527.03,20.59)
        --     },

        --     Itens = {
        --         {
        --             item = "cocaina", -- SPAWN DO ITEM
        --             time = 3, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 2, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
        --             requires = {
        --                 { item = "pastabase" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --             }
        --         },

        --     }
        -- },
        ['Hellzera'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentehellzera",
                location = vec3(-1864.57,2064.28,140.97)
            },

            Itens = {
                {
                    item = "cocaina", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "pastabase" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },
        ['Belgica'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentebelgica",
                location = vec3(-252.72,1532.54,337.57)
            },

            Itens = {
                {
                    item = "cocaina", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "pastabase" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },
        ['suecia'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentesuecia",
                location = vec3(1800.51,420.76,173.0)
            },

            Itens = {
                {
                    item = "cocaina", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "pastabase" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },

        -- LANCA PERFUME
        ['Elements'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerenteelements",
                location = vec3(-153.0,-1590.69,35.05)
            },

            Itens = {
                {
                    item = "lancaperfume", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "respingodesolda" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },
        ['China'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentechina",
                location = vec3(-825.45,-723.82,23.78)
            },

            Itens = {
                {
                    item = "lancaperfume", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "respingodesolda" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },
        ['Grecia'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentegrecia",
                location = vec3(-330.36,-1568.98,25.22)
            },

            Itens = {
                {
                    item = "lancaperfume", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "respingodesolda" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },
        ['Viladochaves'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerenteviladochaves',
                location = vec3(316.01,-206.84,54.07)
            },

            Itens = {
                {
                    item = "lancaperfume", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "respingodesolda" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },
        ['Russia'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerenteliderrussia",
                location = vec3(1386.86,-1262.71,82.02)
            },

            Itens = {
                {
                    item = "haxixe", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "resinacannabis" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },

        -- HEROINA
      
        ['Roxos'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerenteroxos",
                location = vec3(109.36,-1976.25,20.96)
            },

            Itens = {
                {
                    item = "heroina", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "morfina" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },
        ['Italia'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerenteitalia',
                location = vec3(-2461.74,-209.6,35.01)
            },

            Itens = {
                {
                    item = "heroina", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "morfina" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },
            }
        },
        ['Vagos'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentevagos",
                location = vec3(335.44,-2018.54,22.39)
            },

            Itens = {
                {
                    item = "cocaina", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "pastabase" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },
            }
        },

        -- METANFETAMINA
        ['Argentina'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerenteargentina",
                location = vec3(822.47,1062.08,292.58)
            },

            Itens = {
                {
                    item = "metanfetamina", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "anfetamina" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },

        ['Mercenarios'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentemercenarios',
                location = vec3(-112.6,992.22,240.83)
            },

            Itens = {
                {
                    item = "metanfetamina", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "anfetamina" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },
   

        -- OPIO

        ['Anonymous'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerenteanonymous',
                location = vec3(719.06,-961.64,30.4)
            },

            Itens = {
                {
                    item = "opio", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "opiopapoula" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },
        ['Colombia'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentelidercolombia",
                location = vec3(-803.3,185.7,72.61)
            },

            Itens = {
                {
                    item = "opio", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "opiopapoula" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },

        -- HAXIXE


        -- ['Portugal'] = {
        --     Config = {
        --         hasDominas = nil,
        --         permission = "perm.gerenteportugal",
        --         location = vec3(802.41,-292.36,69.47)
        --     },

        --     Itens = {
        --         {
        --             item = "haxixe", -- SPAWN DO ITEM
        --             time = 3, -- Tempo de craft por Unidade [ em segundos ]
        --             customAmount = 2, -- Oque cada unidade vai fabricar
        --             anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
        --             requires = {
        --                 { item = "resinacannabis" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
        --             }
        --         },
        --     }
        -- },
        ['Abutres'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerenteabutres',
                location = vec3(-575.28,289.24,79.18)
            },

            Itens = {
                {
                    item = "haxixe", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "resinacannabis" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },


            }
        },    
        ['Mexico'] = {
            Config = {
                hasDominas = nil,
                permission = 'perm.gerentemexico',
                location = vec3(-489.62,-1497.5,16.21)
            },

            Itens = {
                {
                    item = "haxixe", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "resinacannabis" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },


            }
        }, 

        -- MACONHA
        ['Irlanda'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerenteirlanda",
                location = vec3(-2239.08,-159.4,86.52)
            },

            Itens = {
                {
                    item = "maconha", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "folhamaconha" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },
            }
        },
        -- BALINHA
        ['Franca'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentefranca",
                location = vec3(-2341.38,1746.89,230.15)
            },

            Itens = {
                {
                    item = "balinha", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "podemd" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },
            }
        },
        ['Croacia'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.lidercroacia",
                location = vec3(1361.7,1914.56,102.55)
            },

            Itens = {
                {
                    item = "balinha", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "podemd" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },

        ['Vermelhos'] = {
            Config = {
                hasDominas = nil,
                permission = "perm.gerentevermelhos",
                location = vec3(-1063.0,-1662.4,4.55)
            },

            Itens = {
                {
                    item = "balinha", -- SPAWN DO ITEM
                    time = 3, -- Tempo de craft por Unidade [ em segundos ]
                    customAmount = 2, -- Oque cada unidade vai fabricar
                    anim = { "amb@prop_human_parking_meter@female@idle_a","idle_a_female" }, -- ANIMAÇÃO DURANTE O CRAFT. (SE O TEMPO ESTIVER 0 DESCONSIDERAR)
        
                    requires = {
                        { item = "podemd" , amount = 1 }, -- ITEM / QUANTIDADE ( POR UNIDADE )
                    }
                },

            }
        },
   
    },

    Storage = {
        -- ARMAS
        ['Egito'] = {
            Config = {
                permission = 'perm.egito',
                location = vec3(406.11,2.73,84.92),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['pecadearma'] = 1000000,
                ['gatilho'] = 1000000,
                ['molas'] = 1000000,
                ['metal'] = 1000000,
            }
        },
        ['Magnatas'] = {
            Config = {
                permission = 'perm.magnatas',
                location = vec3(-2933.61,37.11,11.61),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['pecadearma'] = 1000000,
                ['gatilho'] = 1000000,
                ['molas'] = 1000000,
                ['metal'] = 1000000,
            }
        },
        ['Inglaterra'] = {
            Config = {
                permission = 'perm.inglaterra',
                location = vec3(-1546.78,80.91,53.87),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['pecadearma'] = 1000000,
                ['gatilho'] = 1000000,
                ['molas'] = 1000000,
                ['metal'] = 1000000,
            }
        },
        ['PCC'] = {
            Config = {
                permission = 'perm.pcc',
                location = vec3(-1714.66,-225.5,61.81),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['pecadearma'] = 1000000,
                ['gatilho'] = 1000000,
                ['molas'] = 1000000,
                ['metal'] = 1000000,
            }
        },
        ['Mafia'] = {
            Config = {
                permission = 'perm.mafia',
                location = vec3(-1510.02,837.53,181.59),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['pecadearma'] = 1000000,
                ['gatilho'] = 1000000,
                ['molas'] = 1000000,
                ['metal'] = 1000000,
            }
        },
        ['Milicia'] = {
            Config = {
                permission = 'perm.milicia',
                location = vec3(-3101.56,1732.04,36.13),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['pecadearma'] = 1000000,
                ['gatilho'] = 1000000,
                ['molas'] = 1000000,
                ['metal'] = 1000000,
            }
        },
        ['CV'] = {
            Config = {
                permission = 'perm.cv',
                location = vec3(3020.42,3010.83,91.58),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['pecadearma'] = 1000000,
                ['gatilho'] = 1000000,
                ['molas'] = 1000000,
                ['metal'] = 1000000,
            }
        },
        ['Grota'] = {
            Config = {
                permission = 'perm.grota',
                location = vec3(1254.03,-223.91,96.04),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['pecadearma'] = 1000000,
                ['gatilho'] = 1000000,
                ['molas'] = 1000000,
                ['metal'] = 1000000,

            }
        },

        -- MUNIÇÃO
        ['Espanha'] = {
            Config = {
                permission = 'perm.espanha',
                location = vec3(-1466.86,-44.53,54.64),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['polvora'] = 1000000,
                ['capsulas'] = 1000000,
                ['money'] = 1000000,
            }
        },
        ['Cartel'] = {
            Config = {
                permission = 'perm.cartel',
                location = vec3(1395.14,1130.44,109.74),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['polvora'] = 1000000,
                ['capsulas'] = 1000000,
                ['money'] = 1000000,
            }
        },
        ['Tequila'] = {
            Config = {
                permission = 'perm.tequila',
                location = vec3(189.37,1709.94,227.39),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['polvora'] = 1000000,
                ['capsulas'] = 1000000,
                ['money'] = 1000000,
            }
        },
        ['Escocia'] = {
            Config = {
                permission = 'perm.escocia',
                location = vec3(1421.12,-2508.38,55.07),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['polvora'] = 1000000,
                ['capsulas'] = 1000000,
                ['money'] = 1000000,
            }
        },
        ['Yakuza'] = {
            Config = {
                permission = 'perm.yakuza',
                location = vec3( -903.11,-1446.0,7.53),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['polvora'] = 1000000,
                ['capsulas'] = 1000000,
                ['money'] = 1000000,
            }
        },
        ['ADA'] = {
            Config = {
                permission = 'perm.ada',
                location = vec3(786.19,-258.89,73.57),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['polvora'] = 1000000,
                ['capsulas'] = 1000000,
                ['money'] = 1000000,
            }
        },
       
        ['TCP'] = {
            Config = {
                permission = 'perm.tcp',
                location = vec3(1421.89,-767.74,71.71),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['polvora'] = 1000000,
                ['capsulas'] = 1000000,
                ['money'] = 1000000,
            }
        },


        -- LAVAGEM
        ['Galaxy'] = {
            Config = {
                permission = 'perm.galaxy',
                location = vec3(-226.29,-293.93,29.25),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['dirty_money'] = 1000000,
                ['l-alvejante'] = 1000000,
                ['poliester'] = 1000000,
                ['fibradecarbono'] = 1000000, 
                ['ferro'] = 1000000,
                ['aluminio'] = 1000000,
            }
        },
        ['Medusa'] = {
            Config = {
                permission = 'perm.medusa',
                location = vec3(748.69,-573.95,29.37),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['dirty_money'] = 1000000,
                ['l-alvejante'] = 1000000,
                ['poliester'] = 1000000,
                ['fibradecarbono'] = 1000000, 
                ['ferro'] = 1000000,
                ['aluminio'] = 1000000,
            }
        },
        ['Bahamas'] = {
            Config = {
                permission = 'perm.bahamas',
                location = vec3(-1388.58,-612.58,30.31),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['dirty_money'] = 1000000,
                ['l-alvejante'] = 1000000,
                ['poliester'] = 1000000,
                ['fibradecarbono'] = 1000000, 
                ['ferro'] = 1000000,
                ['aluminio'] = 1000000,
            }
        },
        ['Vanilla'] = {
            Config = {
                permission = 'perm.vanilla',
                location = vec3(108.85,-1304.58,28.8),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['dirty_money'] = 1000000,
                ['l-alvejante'] = 1000000,
                ['poliester'] = 1000000,
                ['fibradecarbono'] = 1000000,
                ['ferro'] = 1000000,
                ['aluminio'] = 1000000,
            }
        },  
        ['Lux'] = {
            Config = {
                permission = 'perm.lux',
                location = vec3(-286.47,232.78,78.82),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['dirty_money'] = 1000000,
                ['l-alvejante'] = 1000000,
                ['poliester'] = 1000000,
                ['fibradecarbono'] = 1000000,
                ['ferro'] = 1000000,
                ['aluminio'] = 1000000,
            }
        },  
        ['Cassino'] = {
            Config = {
                permission = 'perm.cassino',
                location = vec3(961.89,38.67,71.85),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['dirty_money'] = 1000000,
                ['l-alvejante'] = 1000000,
                ['poliester'] = 1000000,
                ['fibradecarbono'] = 1000000, 
                ['ferro'] = 1000000,
                ['aluminio'] = 1000000,
            }
        },

        -- DESMANCHE
        ['Pedreira'] = {
            Config = {
                permission = 'perm.pedreira',
                location = vec3(1715.1,-2083.04,110.74),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['ferro'] = 1000000,
                ['aluminio'] = 1000000,
                ['papel'] = 1000000,
                ['money'] = 1000000,
                ['poliester'] = 1000000,
                ['fibradecarbono'] = 1000000,
            }
        },
        ['Bennys'] = {
            Config = {
                permission = 'perm.bennys',
                location = vec3(-239.47,-1315.04,30.89),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['ferro'] = 1000000,
                ['aluminio'] = 1000000,
                ['papel'] = 1000000,
                ['money'] = 1000000,
                ['poliester'] = 1000000,
                ['fibradecarbono'] = 1000000,
            }
        },
        ['Lacoste'] = {
            Config = {
                permission = 'perm.lacoste',
                location = vec3(725.73,-1066.7,28.31),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['ferro'] = 1000000,
                ['aluminio'] = 1000000,
                ['papel'] = 1000000,
                ['money'] = 1000000,
                ['poliester'] = 1000000,
                ['fibradecarbono'] = 1000000,
            }
        },
        ['CDD'] = {
            Config = {
                permission = 'perm.cdd',
                location = vec3(-1181.92,-1736.41,11.9),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['ferro'] = 1000000,
                ['aluminio'] = 1000000,
                ['papel'] = 1000000,
                ['money'] = 1000000,
                ['poliester'] = 1000000,
                ['fibradecarbono'] = 1000000,
            }
        },
        ['HellsAngels'] = {
            Config = {
                permission = 'perm.hellsangels',
                location = vec3(1003.75,-2550.36,28.29),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['ferro'] = 1000000,
                ['aluminio'] = 1000000,
                ['papel'] = 1000000,
                ['money'] = 1000000,
                ['poliester'] = 1000000,
                ['fibradecarbono'] = 1000000,
            }
        },
        ['MotoClub'] = {
            Config = {
                permission = 'perm.motoclub',
                location = vec3(977.13,-104.13,74.85),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['ferro'] = 1000000,
                ['aluminio'] = 1000000,
                ['papel'] = 1000000,
                ['money'] = 1000000,
                ['poliester'] = 1000000,
                ['fibradecarbono'] = 1000000,
            }
        },


        -- COCAINA        
        ['Faveladamare'] = {
            Config = {
                permission = 'perm.faveladamare',
                location = vec3(-1937.28,4522.67,20.46),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['pastabase'] = 1000000,
            }
        },
        ['Hellzera'] = {
            Config = {
                permission = 'perm.hellzera',
                location = vec3(-1870.36,2059.19,135.44),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['pastabase'] = 1000000,
            }
        },
        ['Belgica'] = {
            Config = {
                permission = 'perm.belgica',
                location = vec3(-300.02,1560.45,361.28),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['pastabase'] = 1000000,
            }
        },
        ['suecia'] = {
            Config = {
                permission = 'perm.suecia',
                location = vec3(1854.94,422.0,166.7),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['pastabase'] = 1000000,
            }
        },

        -- MACONHA
        ['Vidigal'] = {
            Config = {
                permission = 'perm.vidigal',
                location = vec3(299.91,1879.02,206.58),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['folhamaconha'] = 1000000,
            }
        },
      
        ['Israel'] = {
            Config = {
                permission = 'perm.israel',
                location = vec3(-1570.58,272.96,68.75),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['folhamaconha'] = 1000000,
            }
        },
        
        -- METANFETAMINA
        ['Argentina'] = {
            Config = {
                permission = 'perm.argentina',
                location = vec3(876.8,1036.28,280.72),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['anfetamina'] = 1000000,
            }
        },


        -- HAXIXE

        ['Portugal'] = {
            Config = {
                permission = 'perm.portugal',
                location = vec3(717.67,-282.5,62.26),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['resinacannabis'] = 1000000,
            }
        },
        ['Mexico'] = {
            Config = {
                permission = 'perm.mexico',
                location = vec3(-482.05,-1474.1,16.6),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['resinacannabis'] = 1000000,
            }
        },
        ['Abutres'] = {
            Config = {
                permission = 'perm.abutres',
                location = vec3(-550.29,286.65,82.97),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['resinacannabis'] = 1000000,
            }
        },

        -- OPIO
        
        ['Anonymous'] = {
            Config = {
                permission = 'perm.anonymous',
                location = vec3(715.44,-974.33,30.4),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['opiopapoula'] = 1000000,
            }
        },
        ['Colombia'] = {
            Config = {
                permission = 'perm.colombia',
                location = vec3(-806.28,171.57,72.84),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['opiopapoula'] = 1000000,
            }
        },

        -- LANCA PERFUME
        ['Russia'] = {
            Config = {
                permission = 'perm.russia',
                location = vec3(1305.5,-1313.43,52.7),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['resinacannabis'] = 1000000,
            }
        },
        ['Elements'] = {
            Config = {
                permission = 'perm.elements',
                location = vec3(-136.28,-1610.78,35.03),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['respingodesolda'] = 1000000,
            }
        },
        ['Viladochaves'] = {
            Config = {
                permission = 'perm.viladochaves',
                location = vec3(337.18,-224.74,58.01),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['respingodesolda'] = 1000000,
            }
        },
        ['China'] = {
            Config = {
                permission = 'perm.china',
                location = vec3(-824.41,-715.59,23.78),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['respingodesolda'] = 1000000,
            }
        },
        ['Grecia'] = {
            Config = {
                permission = 'perm.grecia',
                location = vec3(-352.78,-1538.25,27.72),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['respingodesolda'] = 1000000,
            }
        },

        -- HEROINA
        ['Vagos'] = {
            Config = {
                permission = 'perm.vagos',
                location = vec3(353.57,-2032.87,22.39),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['pastabase'] = 1000000,
            }
        },
       
        ['Roxos'] = {
            Config = {
                permission = 'perm.roxos',
                location = vec3(107.1,-1982.63,20.96),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['morfina'] = 1000000,
            }
        },
        ['Italia'] = {
            Config = {
                permission = 'perm.italia',
                location = vec3(-2455.99,-201.09,35.01),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['morfina'] = 1000000,
            }
        },
        ['Mercenarios'] = {
            Config = {
                permission = 'perm.mercenarios',
                location = vec3(-64.04,998.33,239.47),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['anfetamina'] = 1000000,
            }
        },

        -- BALINHA

        ['Vermelhos'] = {
            Config = {
                permission = 'perm.vermelhos',
                location = vec3(-1080.43,-1671.33,4.7),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['podemd'] = 1000000,
            }
        },
        ['Franca'] = {
            Config = {
                permission = 'perm.franca',
                location = vec3(-2360.3,1705.72,234.09),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['podemd'] = 1000000,
            }
        },

        ['Irlanda'] = {
            Config = {
                permission = 'perm.irlanda',
                location = vec3(-2202.09,-201.58,65.07),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['folhamaconha'] = 1000000,
            }
        },
        ['Croacia'] = {
            Config = {
                permission = 'perm.croacia',
                location = vec3(1387.07,1913.74,102.31),
            },

            List = {
                -- ITEM / QUANTIDADE MAXIMA
                ['podemd'] = 1000000,
            }
        },
        
    },

    Weebhooks = {
        ['Grecia'] = "https://discord.com/api/webhooks/1136680657892946000/XPmwpJnS1ZEHWfob01IoHhyuBhz6U7dmzZYt80oo8-YuCbrSOGwCreQeXeB8Wo6G4fBv",
        ['Grota'] = "https://discord.com/api/webhooks/1148666019527798914/hbkZ4mHGw4-u--dJUhkpPECXXVDflczUT_0fBhCRoBI7beDywyf21JnEv-h-1NOAjsLm",
        ['CV'] = "https://discord.com/api/webhooks/1136333791867183174/Co7x9_FeOQTzXmvxsXKPYM8tjZwhfiOT85MSc7J3pKvlpfX12lDASH2ctnLupC9nfwj2",
        ['PCC'] = "https://discordapp.com/api/webhooks/1115903019213660191/MwGY7zonbmklkTZ6UdnQl6oZ7Hhg07JuwL7gy3TZo09DTFDT2cy0IuetdKxApa3OBO7T",
        ['Milicia'] = "https://discordapp.com/api/webhooks/1115903145298645054/xXrVKXsYWueG1tjFW1aTPuwCyM5RQq2WrW83j1C8HfRYC4-G3nuDaacGoTUjaxZK-0r5",
        ['Mafia'] = "https://discordapp.com/api/webhooks/1115903263670272071/cxWDMtlbwtTYUIEJWWelXXmltxOHyv4IJ1NUSz2DG39mBfCTnju9zT0eQ9Ehhkp8G-0U",
        ['Portugal'] = "https://discordapp.com/api/webhooks/1115903399955791942/q-7WU-pTAaIPkz9HHnHAtZLoBRwTKXhjBgZ1HZOfhMW2URqO936B07xqLgD1ekHiBKUa",
        ['Yakuza'] = "https://discordapp.com/api/webhooks/1115903516427440249/NNULNDqt-ylC673Aah7o_NxsmgOB4IXMTIe3vMKBjimcTJbLAG86q86cYQS7M5j2k7fo",
        ['TCP'] = "https://discordapp.com/api/webhooks/1115903640058744852/_UAEELNayaA6k8hNeADYLidWZeiCJtpcGG5W-xKbiQkSLhRR9Cs8_bpqrWZaip7xhWSN",
        ['ADA'] = "https://discord.com/api/webhooks/1144424481251663902/ikHxiSxd-6tW_WdXzeExgP8_lOBTdeLTtIMQ-JE1cukQ192qidcd1cg8adGOIucOflSJ",
        ['Cartel'] = "https://discordapp.com/api/webhooks/1115904094838726686/OF-TYtGlNFpuYl-6W-2UfoNN_68qNGjheYkjQzpzBWmmPoVkz0FgTYaE-MkFjrHv9mlW",
        ['CDD'] = "https://discord.com/api/webhooks/1151687824400203857/rOPF7LRmEKWUyn-4eLCoob3QJQpNNPvWJ5Mn7ydXYzpgXpG30nJYcyLuKnD2HNd94t34",
        ['Espanha'] = "https://discordapp.com/api/webhooks/1115904386015690863/5SuDbsmS9jUfEqnzr5z3qHzrVuydRbrgYY1UWEbDgzAkYWPP2y-PovfezrBwGADFRDss",
        -- ['Cyclone'] = "https://discordapp.com/api/webhooks/1115904533852340234/rxH27lKaCSwpyVMf1FALlV7oFWn8bsQS-5c4ba1-kILPqE1Dw6G4tVuN0t4r7wWla9OO",
        ['Tequila'] = "https://discordapp.com/api/webhooks/1115904708448636990/D2aGeqeu9FxXcefb0yXaDKPvHyhYcCc-j_UoY6z9Ewsr2q7PD8HWnY8umSzP2t6lIKNb",
        ['Egito'] = "https://discordapp.com/api/webhooks/1115905109268906006/FyW43XtDMlcxrs9rilx5BEX2e8YiwlglZGTziXRoqkx4vPo1tC0_058kRj6z_BWuJ8Ue",
        ['Mercenarios'] = "https://discord.com/api/webhooks/1115908507972157451/0PdBodUQv72970yXklR65q6wE241x8e18tWYGAMQHVuQmiE3EZWpjqz1-XAHvnufpkDF",
        ['Abutres'] = "https://discord.com/api/webhooks/1115916021249867796/LKImwwTO6qYM1LUS9jHDNZjpeHJQ9iJXRq6KuOamYGG-CfUe2M2CYvrZBJzXElRS5AdY",
        ['MotoClub'] = "https://discord.com/api/webhooks/1115916207753805824/Jv-e3emg4UpndEVhVng7DQ7iCuaknR2S7TvFOzLFjWuRUIVvbYJL81iRuYamOaH3w5CV",
        ['Bennys'] = "https://discord.com/api/webhooks/1115924583984402482/QBus6k6CpXpD969eqXUeRByUf9lUAvPZ60oHOBlmCjWYBb7x1J514i8G-InB-BxcpD2H",
        ['Italia'] = "https://discord.com/api/webhooks/1115924738502565929/Q6SEQSXJZCDLX-dfBdoG4asMpFeiDtmaK_T7iNuoalBs-wW_hcprqTi5Aj4R0t6wS2Ft",
        ['Pedreira'] = "https://discord.com/api/webhooks/1115925190480760833/-rj96buyLUhxmMkkE5cZFRHEMLk74G5kHumTlFgE5PKeRr1wa9UntXVMZk1NjToSNMbM",
        ['Bahamas'] = "https://discord.com/api/webhooks/1116067458764251196/UhDOzjd-4ynBsaDot0JENDLmpLgf5h0eNYyEXtPlm2ts1o-uhDBD-uziyk2Abkw-pO9O",
        ['Vanilla'] = "https://discord.com/api/webhooks/1116067607972421743/umMvnHbUvd-MKwfXX0bBb9fKOZ8_4jSX-cOkgCzb3M28bZmafnHlhU7K3_ufqG1mtPtY",
        ['Cassino'] = "https://discord.com/api/webhooks/1116067736192290927/Zs1S0HXGnwa02MuszxL6o3c3bOhSQ2oYCbgWxGrEgDbSzWQHqu-fISKghCxTPakR5i0X",
        ['Galaxy'] = "https://discord.com/api/webhooks/1116067856371679273/ItJtdD7FjT0T6_APiNfRzgQey4iITlI0ifPzdN9fejy4olQRGo4xYKr8lwI6ougIWfhE",
        -- ['Castelinho'] = "https://discord.com/api/webhooks/1116067993126961152/djmQiKCVATHz-aa6k4ft6EbfU6DrCavIYIP8JZ5tYr5Ubo3nKrVVOqYIVswqHaNUX8Gi",
        ['Medusa'] = "https://discord.com/api/webhooks/1116068093412790282/mkoXrTRdW3mHHAxrbg1Dn9XoO4DZjmjgKngZEGv_CE0DsEOQSVrkbkal5whjUf9SRbX6",
        ['Elements'] = "https://discord.com/api/webhooks/1116068251655471114/-tksFAJxv9ZiBAHv1pw_IgY4Wv67wpXyGbY34rfUwa53JJHS7iRqBrC6VSOKM8imZp9W",
        ['Croacia'] = "https://discord.com/api/webhooks/1116068413178126439/NJ3pToV2AplQ_BvBTsXFWdPZCUvXH_vEFyyvkS2FYmF8nUM2-GCrpuz7p68DPhlza5KR",
        ['Russia'] = "https://discord.com/api/webhooks/1116068768855113848/0Y_AzX6-gkXsqino2SJ6LPyQUoWVhEW5Hdm6P8gYjQ48A9RgTckFqzt-9rQrzI6SDWqg",
        ['Vidigal'] = "https://discord.com/api/webhooks/1116069343575408670/ZjCnOUUJUFt5MjyP732ghutQYKHYdGH7E1H9DZPiUtG62yV7RVKsrsUadILVgy4XeOOt",
        ['Belgica'] = "https://discord.com/api/webhooks/1116069536488231003/j5L1txwyhHn2yuThK4P6lUrNEhUqOuUQj92RD8O0Iiz0CWOtvqzIeVs6b-jBWJiD2qo6",
        ['Argentina'] = "https://discord.com/api/webhooks/1116071857255358575/kB726_6gllDiBbBAwmHSrKclmFhIcYqqiGNGw3Z2MEI5r031_EOivGk6Ftax0NHvRRKf",
        ['Israel'] = "https://discord.com/api/webhooks/1115915857592320072/yWNnlcOKveZvEhmMSeRb0-UKM3UY0M8ySkrid4ywNKwB5iKczrJTqplM81OZTRpuFlQC",
        ['Franca'] = "https://discord.com/api/webhooks/1116085891551723611/JtrwbfLH6kW3UGUSaBNbXJr8u_9QIwU-rMSE2_42StZw3LGcJqhCiKuPbDlpSTrKGEM0",
        ['Vagos'] = "https://discord.com/api/webhooks/1116086158242349086/SYj3K7dEF83cF0z0IXEtt3dTwtAIbaVNckFtRGdl2ruBZaBNhzAkkWa0t64vCeeSN8SZ",
        ['Lacoste'] = "https://discord.com/api/webhooks/1115903674162618439/xHXoQhL1qBpkVyC9J9YQGIVWTXwslkrGJnsH1bgHm62rfbvnwKwRdUkOWG_Cxyamotgp",
        ['Inglaterra'] = "https://discord.com/api/webhooks/1119354430408626186/f47TnJ3qS0lZMOpLUGlAvTb689tFUrkFi1J74CzFbPE5reE7J1S4lLKeRpXx5X6YNafO",
        -- ['Playboy'] = "https://discord.com/api/webhooks/1119066738923929760/ooClIK790jqQan6OrFdLOEykZgMKcrPz2J5hZx3TH5mn7ursGroVx_8G3NkXBu1PhmRs",
        ['Magnatas'] = "https://discord.com/api/webhooks/1124422991992868965/nAVqb5e9DRICvKq7_8kt3h47Ebn5gEOVT3vh_d_yHTK2OT-cWddoUnsH9J7UoIyJUEfV",
        ['Viladochaves'] = "https://discord.com/api/webhooks/1121972273260277790/uvHLoZ7WybaCiIbeo9kUPMfAEPH-x5A_1oSc9SV9JsA-0I4Kx8FBhUecYewZ7TqqWFDP",
        ['Roxos'] = "https://discord.com/api/webhooks/1128716349573693480/sRXeuq1KxrZmK9kHlu0Gj91dGzfP7nuUHvKcGIb-Lh-HetuOghQth18x28UqPf2NwAwO",
        ['Vermelhos'] = "https://discord.com/api/webhooks/1121970911642398730/AUWYrNG_OWglxKwL0QJWcMqwKxkGV434wkkaEnPdaeVgeKXnKEW3bQ4VgxOnqukVnCZX",
        ['Anonymous'] = "https://discord.com/api/webhooks/1121969692693758022/FKd2G3qTJh9Gi0sFeuNsHFiGaCDgZYJS3k9NVfAxhik4Juj4bcXvSwth6CEBAL17toEp",
        ['China'] = "https://discord.com/api/webhooks/1121970078540378122/k9v3xH9PWL9S0IRvTka4QpsDDQSuVif6mhybT0kVQotAwZBfJZJvsDKWifpVCxF6-6ee",
        ['Colombia'] = "https://discord.com/api/webhooks/1125512377962606722/kAou5FlQQuxcq_BlHSp5KPCNhT6LSaUwS3OPMrEkUWhFg8myPfGCF-zJK8OCx6k_PRdB",
        ['Lux'] = "https://discord.com/api/webhooks/1141531945327665152/SP8fZ5KK0ao-Ofj5x93lyKIrYbF8aCFyBcnQQ7ju-Jp2D8THB3WtTm__rYJbx78B5JMI",
        
    },

}
