---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local Craft = {
    List = {
        -- ["Dominacao [ARMAS]"] = {
        --     {
        --         item = "WEAPON_SNSPISTOL_MK2",
        --         name = "Fajuta",
        --         time = 7,
        --         anim = {
        --             "amb@prop_human_parking_meter@female@idle_a",
        --             "idle_a_female"
        --         }
        
        --         ["requires"] = {
        --             {
        --                 item = "pecadearma",
        --                 name = "Pe├ºa de arma",
        --                 amount = 15
        --             },
        --             {
        --                 item = "gatilho",
        --                 name = "Gatilho",
        --                 amount = 1
        --             },
        --             {
        --                 item = "molas",
        --                 name = "Molas",
        --                 amount = 5
        --             },
        --             {
        --                 item = "metal",
        --                 name = "Placa de Metal",
        --                 amount = 5
        --             },
        --             {
        --                 item = "money",
        --                 name = "Dinheiro",
        --                 amount = 25000
        --             }
        --         },
        --     },
        -- }
    },


    Users = {}
}

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FUNCTIONS CRAFT
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Craft:StartPlayerCraft(ply, craft)
    local ply,craft = ply,craft

    self.Users[ply.source] = true

    if vRP.computeInvWeight(ply.user_id)+vRP.getItemWeight(craft.item)*parseInt(craft.amount) <= vRP.getInventoryMaxWeight(ply.user_id) then
        vTunnel._BlockAnims(ply.source, true, craft.anim)
        TriggerClientEvent("Progress", ply.source, craft.time)

        SetTimeout(craft.time * 1000, function()
            self.Users[ply.source] = false
            vTunnel._BlockAnims(ply.source, false)

            corpoHook = { 
                { 
                    ["color"] = 6356736, 
                    ["title"] = "**".. ":man_construction_worker: | Craft de Item " .."**\n", 
                    ["thumbnail"] = { ["url"] = 'https://media.discordapp.net/attachments/980387548721455134/1096229393891856466/TOKYO-01_2.png?width=867&height=662' }, 
                    ["description"] = "**USER_ID:**\n```cs\n"..ply.user_id.."```\n**CRAFTOU:** ```css\n".. craft.item .." " .. parseInt(craft.amount) .."x```\n**MESA:**\n ```cs\n"..craft.org.."```", 
                    ["footer"] = { ["text"] = "© LOTUS GROUP", }, 
                } 
            }
            sendToDiscord(CraftConfig.Weebhooks[craft.org], corpoHook)

            vRP.giveInventoryItem(ply.user_id, craft.item, craft.amount, true)
 
        end)
    else
        self.Users[ply.source] = false
        TriggerClientEvent("Notify",ply.source,"negado","Mochila cheia.", 5)
    end
end

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TUNNELS CRAFT
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- function RegisterTunnel.checkOpenCraft(id)
--     local source = source
--     local user_id = vRP.getUserId(source)
--     if not user_id then return end
    
--     -- CHECANDO SE TEM DOMINAÇÃO
--     local hasDominas = CraftConfig.Tables[id].Config.hasDominas or false
--     if hasDominas then
--         local data = exports['dm_module']:GetUserDomination(user_id)
--         if not data then 
--             TriggerClientEvent("Notify",source,"negado","Sua organização não dominou essa area.")
--             return false
--         end

--         if hasDominas == data.zone then
--             return true
--         end
--     else
--         -- CHECANDO SE TEM PERMISSAO
--         local Permission = CraftConfig.Tables[id].Config.permission
--         if Permission and vRP.hasPermission(user_id, Permission) then
--             return true
--         end
--     end

--     TriggerClientEvent("Notify",source,"negado","Você não possui permissão para acessar.")
--     return false
-- end


function RegisterTunnel.checkOpenCraft(id)
    local source = source
    local user_id = vRP.getUserId(source)
    local Permission = CraftConfig.Tables[id].Config.permission
    if not user_id then return end

    -- CHECANDO SE TEM DOMINAÇÃO
    local hasDominas = CraftConfig.Tables[id].Config.hasDominas or false
    if hasDominas then
        local data = exports['dm_module']:GetUserDomination(user_id)
        local userOrg = vRP.getUserGroupOrg(user_id)
        if not data then
            TriggerClientEvent("Notify",source,"negado","Sua organização não dominou essa área.")
            return false
        end

        local isZoneDominated = false
        for _, zoneData in ipairs(data.zones) do
            if hasDominas == zoneData.zone and userOrg == zoneData["orgName"] then
                isZoneDominated = true
                break
            end
        end

        if isZoneDominated then
            if Permission and vRP.hasPermission(user_id, Permission) then
                return true
            end
            TriggerClientEvent("Notify",source,"negado","Você não possui permissão para acessar.")
            return false
        else
            TriggerClientEvent("Notify",source,"negado","Sua organização não dominou essa área.")
            return false
        end
    end

    -- CHECANDO SE TEM PERMISSAO
    if Permission and vRP.hasPermission(user_id, Permission) then
        return true
    end

    TriggerClientEvent("Notify",source,"negado","Você não possui permissão para acessar.")
    return false
end

function RegisterTunnel.requestCraft(id)
    local source = source
    local user_id = vRP.getUserId(source)
    if not user_id then return end

    local myOrg = vRP.getUserGroupOrg(user_id)
    if not myOrg then return end

    local StorageItens = json.decode(vRP.getSData('armazem:'..myOrg)) or {} 
    local FormatItems = {}
    for item,amount in pairs(StorageItens) do
        FormatItems[#FormatItems + 1] = {
            name = vRP.getItemName(item),
            amount = amount
        }
    end

    return Craft.List[id] or {},FormatItems
end

function RegisterTunnel.startProduction(table, index, amount)
    if amount <= 0 then amount = 1 end

    local source = source
    local user_id = vRP.getUserId(source)
    if not user_id then return end

    local myOrg = vRP.getUserGroupOrg(user_id)
    if not myOrg then 
        return 
    end

    if Craft.Users[source] then
        TriggerClientEvent("Notify",source, "negado","Você já está fabricando um item.")
        return
    end

    local Table = CraftConfig.Tables[table]
    if not Table then 
        return 
    end

    local Storage = CraftConfig.Storage[myOrg]

    if not Storage then 
        return 
    end
    local StorageItens = json.decode(vRP.getSData('armazem:'..myOrg)) or {}
    local StorageList = Storage.List

    local NecessarityItems = {}
    for k,v in pairs(Table.Itens[index].requires) do
        NecessarityItems[v.item] = v.amount * amount
    end
    
    local StartCraft = true
    local ErrorMessage = ""
    for item,amount in pairs(NecessarityItems) do
        if not StorageItens[item] then StorageItens[item] = 0 end

        if StorageItens[item] < amount then
            ErrorMessage = ErrorMessage.. ("<br>Item <b>%s</b> quantidade <b>%s/%s</b>"):format(vRP.getItemName(item), StorageItens[item], amount)
            StartCraft = false
        end
    end

    if not StartCraft then
        TriggerClientEvent("Notify",source, "negado","O Armazem não possui: <br>"..ErrorMessage)
        return
    end

    if vRP.computeInvWeight(user_id)+vRP.getItemWeight(Table.Itens[index].item)*parseInt(Table.Itens[index].customAmount * amount) <= vRP.getInventoryMaxWeight(user_id) then
        for item,amount in pairs(NecessarityItems) do
            StorageItens[item] -= amount
        end
        vRP.setSData('armazem:'..myOrg, json.encode(StorageItens))

        Craft:StartPlayerCraft(
            { 
                source = source, 
                user_id = user_id 
            }, 
            {
                item = Table.Itens[index].item,
                org = myOrg,
                amount = Table.Itens[index].customAmount * amount,
                time = (Table.Itens[index].time * amount),
                anim = Table.Itens[index].anim
            }
        )
    else
        TriggerClientEvent("Notify",source,"negado","Mochila cheia.", 5)
        return 
    end
end 

function RegisterTunnel.storageList(index)
    local source = source
    local user_id = vRP.getUserId(source)
    if not user_id then return end

    local Storage = CraftConfig.Storage[index]
    if not Storage then return end

    if not vRP.hasPermission(user_id, Storage.Config.permission) then
        TriggerClientEvent("Notify",source, "negado","Você não possui permissão.")
        return
    end

    local StorageItens = json.decode(vRP.getSData('armazem:'..index)) or nil
    if not StorageItens then
        TriggerClientEvent("Notify",source, "negado","O Armazem não possui Itens.")
        return
    end

    local Text = ""
    for item,amount in pairs(StorageItens) do
        Text = Text.. '<br>Item: <b>'..vRP.getItemName(item)..'</b> <b>'..amount..'</b>x'
    end
   
    TriggerClientEvent("Notify",source, "sucesso","Lista de Itens: <br>"..Text, 15)
end


function RegisterTunnel.storageStore(index)
    local source = source
    local user_id = vRP.getUserId(source)
    if not user_id then return end

    local Storage = CraftConfig.Storage[index]
    if not Storage then return end
        
    if not vRP.hasPermission(user_id, Storage.Config.permission) then
        TriggerClientEvent("Notify",source, "negado","Você não possui permissão.")
        return
    end

    local StorageItens = json.decode(vRP.getSData('armazem:'..index)) or {}
    local ItensList = Storage.List
    local Text = ""

    for item,maxAmount in pairs(ItensList) do
        local plyItemAmount = vRP.getInventoryItemAmount(user_id, item)

        if vRP.tryGetInventoryItem(user_id, item, plyItemAmount, true) then
            if StorageItens[item] then
                StorageItens[item] += plyItemAmount

                Text = Text ~= nil and Text.. '<br>Item: '..vRP.getItemName(item).. ' '..plyItemAmount..'x ' or 'Item: '..vRP.getItemName(item).. ' '..plyItemAmount..'x '
            else
                StorageItens[item] = plyItemAmount

                Text = Text ~= nil and Text.. '<br>Item: '..vRP.getItemName(item).. ' '..plyItemAmount..'x ' or 'Item: '..vRP.getItemName(item).. ' '..plyItemAmount..'x '
            end

            exports.bm_module:AddPlayerFarm(user_id, item, plyItemAmount)
        end
    end

    if Text == "" then
        TriggerClientEvent("Notify",source, "negado","Você não possui itens para guardar.")
        return
    end

    vRP.setSData('armazem:'..index, json.encode(StorageItens))
    TriggerClientEvent("Notify",source, "sucesso",'Você guardou: <br>'..Text, 5)

    return true
end

function RegisterTunnel.storageItens(org)
    local source = source
    local user_id = vRP.getUserId(source)
    if not user_id then return end
    
    if not CraftConfig.Storage[org] then return end

    local Storage = CraftConfig.Storage[org].List
    local FormatStorage = {}
    for item in pairs(Storage) do
        FormatStorage[#FormatStorage + 1] = { value = item, name = vRP.getItemName(item) }
    end
    
    return FormatStorage or {}
end

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- GERAR CACHE DOS CRAFTS
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    for tableName in pairs(CraftConfig.Tables) do
        if not Craft.List[tableName] then Craft.List[tableName] = {} end

        local ListItems = CraftConfig.Tables[tableName].Itens
        for i = 1, #ListItems do

            local ActualItem = #Craft.List[tableName] + 1
            local Item = ListItems[i]
            Craft.List[tableName][ActualItem] = {
                item = Item.item,
                name = vRP.getItemName(Item.item),
                time = Item.time,
                anim = Item.anim,
            }

            for i = 1, #Item.requires do
                local Item = Item.requires[i]
                if not Craft.List[tableName][ActualItem].requires then Craft.List[tableName][ActualItem].requires = {} end
                Craft.List[tableName][ActualItem].requires[#Craft.List[tableName][ActualItem].requires + 1] = {
                    item = Item.item,
                    name = vRP.getItemName(Item.item),
                    amount = Item.amount
                } 
            end
        end
    end
end)

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- OTHERS FUNCTIONS
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function sendToDiscord(weebhook, message)
    PerformHttpRequest(weebhook, function(err, text, headers) end, 'POST', json.encode({embeds = message}), { ['Content-Type'] = 'application/json' })
end